from setuptools import setup

setup( 
    name ='econometricsstats', 
    version = '1.0.0', 
    description = 'stats wrapper for econometrics', 
    author = 'sw', 
    author_email = None,
    url = None, 
    py_modules = ['econometrics_stats']
 )

